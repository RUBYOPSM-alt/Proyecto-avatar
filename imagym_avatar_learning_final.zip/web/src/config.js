export const WS_URL = import.meta.env.VITE_WS_URL || 'ws://localhost:3001';
export const AVATAR_PATH = '/public/avatar/imagym_agent.png';
