#!/bin/bash
curl -X POST http://localhost:3001/admin/ingest-site
