Imagym Avatar Project
---------------------
Structure:
- server/: backend Node server (WS, STT, RAG, TTS streaming)
- web/: frontend React component

Steps:
1. Copy .env.example -> .env and fill keys.
2. Install server deps: npm install (in server dir).
3. Start server: npm run dev
4. Start frontend: npm run dev (in web dir)
