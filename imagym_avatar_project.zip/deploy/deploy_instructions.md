Deployment notes:
- Use a provider that supports WebSockets (Railway, Render, Heroku).
- Set environment variables from .env.example.
- Install dependencies and run `npm run start` in the server directory.
